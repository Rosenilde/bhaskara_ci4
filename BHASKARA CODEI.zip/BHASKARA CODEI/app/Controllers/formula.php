<?php

namespace App\Controllers;

use CodeIgniter\Database\MySQLi\Result;

class formula extends BaseController
{
    public function exibeform()
    {
        echo view('nome');
    }
    public function atualiza(){
        echo view('update');
    }
    public function frmInserir()
    {
        if (isset($this->request->getPost()['ID'])){
            $id = @$this->request->getPost()['ID'];
        }else {
$id = false;
            }
$a = $this->request->getPost()['a'];
$b = $this->request->getPost()['b'];
$c = $this->request->getPost()['c'];

$delta = ($b * $b) - (4 * $a * $c);
$x1 = (-$b + sqrt($delta))/(2 * $a);
$x2 = (-$b + sqrt($delta))/(2 * $a);

$bhasModel = new \App\Models\BhaskaraModel();


$data = [
    'a' => $a,
    'b' => $b,
    'c' => $c,
    'delta' => $delta,
    'x1' => $x1,
    'x2' => $x2,
];

if ($id !=false){
    $data['id'] = $id;
}
$result $bhasModel->save($data);
var_dump($result);
    }


public function ler()
$bhasModel = new\App\Models\BhaskaraModel();

        
    
>?