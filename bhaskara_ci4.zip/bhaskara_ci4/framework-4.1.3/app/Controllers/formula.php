<?php

namespace App\Controllers;

use App\Models\formulaModel;

class formula extends BaseController
{
    public function recebe_dados()
    {
        $a = $this->request->getPost()['valor_a'];
        $b = $this->request->getPost()['valor_b'];
        $c = $this->request->getPost()['valor_c']; 
        
        $formulaModel = new \App\Models\formulaModel();

        $data = [
            'a' => $a,
            'b' => $b,
            'c' => $c,
        ];

        $formulaModel->save($data);

        }
        public function formInsert(){

            echo view ('create');
        }
           

    }
