<?php

helper('form');

echo form_open('formula/recebe_dados');

echo form_input('valor a', 'Digite o valor A');
echo form_input('valor b', 'Digite o valor B');
echo form_input('valor c', 'Digite o valor C');
echo form_submit('mysubmit', 'Enviar Dados');
echo form_close();

?>